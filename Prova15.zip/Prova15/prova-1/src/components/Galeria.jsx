export default function Galeria() {
    return(
        <section className="galeria">
            <div>
                <h1>Galeria</h1>
                <img src="../public/aisim.jpeg" alt="Imagem" />
                <img src="../public/download (1).jpeg" alt="Imagem" />
                <img src="../public/download (2).jpeg" alt="Imagem" />
                <img src="../public/download (3).jpeg" alt="Imagem" />
                <img src="../public/download (4).jpeg" alt="Imagem" />
                <img src="../public/download (5).jpeg" alt="Imagem" />
                <img src="../public/download.jpeg" alt="Imagem" />
                <img src="Memes.jpeg" alt="Imagem" />
            </div>
        </section>
    )
}