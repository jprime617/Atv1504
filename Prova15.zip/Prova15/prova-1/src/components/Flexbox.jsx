export default function FlexBox() {
    return(
        <section className="container">
            <div className="div1">
                <h1>Item 1</h1>
            </div>
            <div className="div2">
                <h1>Item 2</h1>
            </div>
            <div className="div3">
                <h1>Item 3</h1>
            </div>
        </section>
    )
}